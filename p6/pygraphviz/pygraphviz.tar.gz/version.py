"""
Version information for PyGraphviz, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.0'
__revision__ = None
__date__ = 'Sun Aug  1 07:58:06 2010'

